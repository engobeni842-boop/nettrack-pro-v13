/* NetTrack Pro V14 — Service Worker
   Strategy:
   - Network-first for index.html / app.js (always get fresh)
   - Cache-first for icons / manifest / external CDNs
   - Auto-evict old caches on activate
*/
const CACHE_NAME = 'nettrack-pro-v14-pwa-v1';
const STATIC_ASSETS = [
  './',
  './index.html',
  './app.js',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);

  // Skip WebSocket and non-GET requests
  if (req.method !== 'GET') return;
  // Skip cross-origin (Binance API, Supabase, etc.) — let the network handle it
  if (url.origin !== location.origin) return;

  // Network-first for HTML/JS so updates land fast
  if (req.destination === 'document' || /\.(html|js)$/.test(url.pathname)) {
    event.respondWith(
      fetch(req).then(res => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(req, copy)).catch(()=>{});
        return res;
      }).catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
    );
    return;
  }

  // Cache-first for everything else (icons, manifest)
  event.respondWith(
    caches.match(req).then(cached => cached || fetch(req).then(res => {
      const copy = res.clone();
      caches.open(CACHE_NAME).then(c => c.put(req, copy)).catch(()=>{});
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});
