/* ============================================================
   NetTrack Pro V14 — Premium Signal Platform
   ARMOROO E n T Software and Apps
   Created by Emmanuel Musiyiwa Ngobeni & Thando Mbatha
   ============================================================
   FIXES from V13.4:
   - Clean WebSocket lifecycle with exponential backoff reconnect.
   - Broker switching no longer disturbs the live USD price feed.
   - Single coherent state machine; no patch-stacking setInterval loops.
   - Chart-aligned Signal Switch button + broker transition toast.
*/

'use strict';

/* ---------- CONFIG ---------- */
const NT_CONFIG = {
  VERSION: 'V14.0.0',
  OWNER_EMAILS: ['engobeni842@gmail.com', 'engobeni842@googlemail.com'],
  DAILY_SIGNAL_LIMIT: 2,
  TRIAL_DAYS: 30,
  WS_URL: 'wss://stream.binance.com:9443/ws',
  WS_RECONNECT_MIN: 1000,
  WS_RECONNECT_MAX: 8000,
  BROKER_PROVIDER_MAP: {
    'Binance': 'Binance', 'Bybit': 'Bybit',
    'Exness': 'Exness', 'XM': 'XM', 'IQ Option': 'IQ Option',
    'MT4': 'MetaTrader 4', 'MT5': 'MetaTrader 5', 'ICMarkets': 'ICMarkets',
    'Deriv': 'Deriv', 'TradingView': 'TradingView'
  },
  // Fallback static prices for non-crypto pairs (no live feed available client-side)
  STATIC_BASE: {
    'BTCUSDT': 61725, 'ETHUSDT': 3350, 'SOLUSDT': 151.9, 'BNBUSDT': 562.6,
    'EURUSD': 1.10995, 'GBPUSD': 1.27120, 'USDJPY': 156.22,
    'XAUUSD': 2358.40, 'V75': 99161.69, 'V100': 1440.25,
    'BOOM1000': 7782.10, 'CRASH1000': 6120.55
  }
};

/* ---------- UTILS ---------- */
const $ = id => document.getElementById(id);
const txt = (id, v) => { const e = $(id); if (e) e.textContent = v; };
const fmtDate = d => new Date(d).toLocaleDateString('en-ZA', { day:'2-digit', month:'short', year:'numeric' });
const fmtTime = d => new Date(d).toLocaleTimeString('en-ZA', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
const precision = sym => /JPY|V75|V100|BOOM|CRASH/i.test(sym) ? 2 :
                        /BTC|ETH|BNB|SOL/i.test(sym) ? 2 :
                        /XAU|Gold/i.test(sym) ? 2 : 5;
const fmtPrice = (n, sym) => Number.isFinite(+n) ? (+n).toFixed(precision(sym)) : '—';

function notify(msg, type='info', ms=3000){
  const el = $('notif'); if (!el) return;
  el.textContent = msg;
  el.className = 'notif show ' + (type || 'info');
  clearTimeout(notify._t);
  notify._t = setTimeout(() => { el.classList.remove('show'); }, ms);
}

/* ---------- AUTH (local + Supabase-ready) ---------- */
const ntAuth = (() => {
  const KEY = 'ntp_v14_session';

  function read(){
    try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch(e) { return null; }
  }
  function write(s){ localStorage.setItem(KEY, JSON.stringify(s)); }
  function clear(){ localStorage.removeItem(KEY); }

  function startTrialIfMissing(s){
    if (!s.trialStart) {
      s.trialStart = Date.now();
      s.trialEnd = Date.now() + NT_CONFIG.TRIAL_DAYS * 86400000;
    }
    return s;
  }

  function init(){
    const s = read();
    if (s && s.email) {
      applySession(s);
      $('authOverlay').classList.add('hidden');
    } else {
      $('authOverlay').classList.remove('hidden');
    }
  }

  function applySession(s){
    txt('navEmail', s.email);
    txt('portalUserEmail', s.email);
    txt('portalUserPlan', s.plan === 'free_trial' ? 'Free Trial' : (s.plan[0].toUpperCase() + s.plan.slice(1)));
    txt('portalTrialEnds', s.trialEnd ? fmtDate(s.trialEnd) : '—');
    const isOwner = NT_CONFIG.OWNER_EMAILS.includes((s.email||'').toLowerCase());
    $('navOwner').classList.toggle('visible', isOwner);
    const daysLeft = Math.max(0, Math.ceil(((s.trialEnd || Date.now()) - Date.now()) / 86400000));
    txt('trialBadge', s.plan === 'free_trial' ? `Free Trial · ${daysLeft} days` : `${s.plan.toUpperCase()} active`);
  }

  function signIn(){
    const email = ($('authEmail').value || '').trim().toLowerCase();
    const pw = $('authPassword').value || '';
    if (!email || !pw) { notify('Enter email and password', 'warn'); return; }
    // Local-first auth (will be replaced by Supabase when keys are added)
    const s = startTrialIfMissing({ email, plan: 'free_trial', paidUntil: 0 });
    write(s); applySession(s);
    $('authOverlay').classList.add('hidden');
    notify(`Welcome back, ${email}`, 'success');
  }

  function signUp(){
    const name = ($('suName').value || '').trim();
    const email = ($('suEmail').value || '').trim().toLowerCase();
    const pw = $('suPassword').value || '';
    if (!email || !pw) { notify('Email and password required', 'warn'); return; }
    if (pw.length < 6) { notify('Password must be at least 6 characters', 'warn'); return; }
    const s = startTrialIfMissing({ email, name, plan: 'free_trial', paidUntil: 0 });
    write(s); applySession(s);
    $('authOverlay').classList.add('hidden');
    notify(`Account created. 30-day trial started. Welcome ${name || email}.`, 'success');
  }

  function guestSignIn(){
    const s = startTrialIfMissing({ email: 'guest@nettrack', plan: 'free_trial', paidUntil: 0, guest: true });
    write(s); applySession(s);
    $('authOverlay').classList.add('hidden');
    notify('Free tester mode. 2 signals/day · 30-day trial.', 'info');
  }

  function signOut(){
    clear();
    location.reload();
  }

  function toggle(which){
    $('authSignIn').classList.toggle('hidden', which !== 'signin');
    $('authSignUp').classList.toggle('hidden', which !== 'signup');
  }

  function session(){ return read() || {}; }
  function isPaid(){
    const s = session();
    return !!(s.paidUntil && Number(s.paidUntil) > Date.now());
  }
  function isOwner(){ return NT_CONFIG.OWNER_EMAILS.includes((session().email||'').toLowerCase()); }

  function openProfile(){ ntApp.showPage('user'); }

  return { init, signIn, signUp, guestSignIn, signOut, toggle, session, isPaid, isOwner, openProfile };
})();

/* ---------- MARKET / WEBSOCKET ENGINE ---------- */
const ntMarket = (() => {
  const state = {
    symbol: 'BTCUSDT',
    timeframe: '5m',
    broker: 'Binance',
    lastBroker: 'Binance',
    candles: [],
    livePrice: 0,
    prevPrice: 0,
    ws: null,
    wsBackoff: NT_CONFIG.WS_RECONNECT_MIN,
    wsAttempts: 0,
    socketLive: false,
    streamTimer: null,
    syntheticMode: false
  };

  function isCryptoSymbol(s){ return /USDT$/.test(s); }

  function changeAsset(){
    const sym = $('assetSelect').value;
    state.symbol = sym;
    state.candles = [];
    txt('dsSymbol', sym);
    txt('dsCandles', '0');
    txt('chipSymbol', $('assetSelect').options[$('assetSelect').selectedIndex].text);
    txt('alignSymbol', $('assetSelect').options[$('assetSelect').selectedIndex].text);
    closeSocket();
    if (isCryptoSymbol(sym)) {
      state.syntheticMode = false;
      connectSocket();
    } else {
      state.syntheticMode = true;
      startSyntheticFeed();
    }
    seedCandles();
    ntChart.render();
    ntSignals.refreshSummary();
  }

  function changeTimeframe(){
    state.timeframe = $('tfSelect').value;
    txt('dsTF', state.timeframe);
    txt('chipTF', state.timeframe);
    state.candles = [];
    seedCandles();
    ntChart.render();
    ntSignals.refreshSummary();
  }

  function changeBroker(){
    const newBroker = $('brokerSelect').value;
    const oldBroker = state.broker;
    if (newBroker === oldBroker) return;
    state.lastBroker = oldBroker;
    state.broker = newBroker;
    txt('dsBroker', newBroker);
    txt('chipBroker', newBroker + ' Overlay');
    txt('alignBroker', newBroker);
    txt('brokerAlignTag', newBroker);
    txt('alignProvider', NT_CONFIG.BROKER_PROVIDER_MAP[newBroker] || newBroker);
    txt('alignLastSwitch', `${oldBroker} → ${newBroker} · ${fmtTime(Date.now())}`);

    // Show the broker switch toast (aligned with chart)
    const toast = $('brokerToast');
    if (toast){
      txt('brokerToastFrom', oldBroker);
      txt('brokerToastTo', newBroker);
      toast.classList.add('show');
      clearTimeout(toast._t);
      toast._t = setTimeout(() => toast.classList.remove('show'), 3200);
    }

    notify(`Switched from ${oldBroker} to ${newBroker} — ${oldBroker} signals replaced with ${newBroker} signals`, 'success');

    // Re-render any existing signals with the new provider label
    ntSignals.relabelProvider();
  }

  /* ---- WebSocket: Binance crypto live ticker ---- */
  function connectSocket(){
    if (!isCryptoSymbol(state.symbol)) return;
    setSocket('CONNECTING', 'connecting');
    try {
      const url = `${NT_CONFIG.WS_URL}/${state.symbol.toLowerCase()}@trade`;
      state.ws = new WebSocket(url);

      state.ws.onopen = () => {
        state.socketLive = true;
        state.wsBackoff = NT_CONFIG.WS_RECONNECT_MIN;
        state.wsAttempts = 0;
        setSocket('LIVE', 'live');
      };

      state.ws.onmessage = (ev) => {
        try {
          const d = JSON.parse(ev.data);
          if (d && d.p) {
            const p = parseFloat(d.p);
            updatePrice(p);
          }
        } catch (e) { /* ignore parse errors */ }
      };

      state.ws.onerror = () => {
        // onclose will fire next; reconnect logic lives there
      };

      state.ws.onclose = () => {
        if (state.socketLive) setSocket('DISCONNECTED', 'dead');
        state.socketLive = false;
        // Only schedule reconnect if user is still on a crypto symbol
        if (!isCryptoSymbol(state.symbol)) return;
        state.wsAttempts++;
        const wait = Math.min(NT_CONFIG.WS_RECONNECT_MAX, state.wsBackoff);
        setSocket(`RECONNECT ${Math.round(wait/1000)}s`, 'dead');
        setTimeout(() => {
          if (isCryptoSymbol(state.symbol)) connectSocket();
        }, wait);
        state.wsBackoff = Math.min(NT_CONFIG.WS_RECONNECT_MAX, state.wsBackoff * 1.8);
      };
    } catch (e){
      setSocket('OFFLINE', 'dead');
      startSyntheticFeed();
    }
  }

  function closeSocket(){
    if (state.ws){
      try { state.ws.onclose = null; state.ws.close(); } catch(e){}
      state.ws = null;
    }
    state.socketLive = false;
    if (state.streamTimer){ clearInterval(state.streamTimer); state.streamTimer = null; }
  }

  function setSocket(label, level){
    txt('socketStatus', label);
    txt('dsSocket', label);
    $('socketDot').classList.remove('live','dead');
    if (level === 'live') $('socketDot').classList.add('live');
    if (level === 'dead') $('socketDot').classList.add('dead');
    $('dsSocket').style.color = level === 'live' ? 'var(--buy)' : level === 'dead' ? 'var(--sell)' : 'var(--neutral)';
  }

  function startSyntheticFeed(){
    closeSocket();
    setSocket('SYNTHETIC', 'live');
    state.socketLive = true;
    const base = NT_CONFIG.STATIC_BASE[state.symbol] || 1;
    state.livePrice = base;
    state.streamTimer = setInterval(() => {
      // Tiny random walk for forex/synthetic
      const vol = /JPY/.test(state.symbol) ? 0.02 : /XAU/.test(state.symbol) ? 0.6 : /V75|V100|BOOM|CRASH/.test(state.symbol) ? base*0.0008 : 0.00005;
      state.livePrice = state.livePrice + (Math.random() - 0.5) * vol * 2;
      updatePrice(state.livePrice);
    }, 1500);
  }

  function updatePrice(p){
    state.prevPrice = state.livePrice;
    state.livePrice = p;
    const el = $('livePrice');
    if (el){
      el.textContent = '$' + fmtPrice(p, state.symbol);
      el.classList.remove('up','down');
      if (p > state.prevPrice) el.classList.add('up');
      else if (p < state.prevPrice) el.classList.add('down');
    }
    txt('dsUpdate', fmtTime(Date.now()));
    // Feed into latest candle
    if (state.candles.length){
      const last = state.candles[state.candles.length-1];
      last.c = p;
      last.h = Math.max(last.h, p);
      last.l = Math.min(last.l, p);
      // Re-render lightly (throttled)
      if (!updatePrice._t || Date.now() - updatePrice._t > 250){
        updatePrice._t = Date.now();
        ntChart.render();
      }
    }
  }

  /* ---- Seed candle history (simulated, for tester chart) ---- */
  function seedCandles(){
    const base = state.livePrice || NT_CONFIG.STATIC_BASE[state.symbol] || 100;
    const vol = /BTC|ETH|BNB|SOL/.test(state.symbol) ? base * 0.004 :
                /V75|V100|BOOM|CRASH/.test(state.symbol) ? base * 0.003 :
                /XAU/.test(state.symbol) ? 1.5 :
                /JPY/.test(state.symbol) ? 0.08 : 0.0008;
    let p = base;
    const out = [];
    const tfMs = { '1m':60000, '5m':300000, '15m':900000, '1h':3600000, '4h':14400000 }[state.timeframe] || 300000;
    for (let i = 80; i >= 0; i--){
      const o = p;
      const r1 = (Math.random() - 0.5) * 2 * vol;
      const r2 = (Math.random() - 0.5) * 2 * vol;
      const c = o + r1;
      const h = Math.max(o, c) + Math.abs(r2);
      const l = Math.min(o, c) - Math.abs(r2);
      out.push({ t: Date.now() - i * tfMs, o, h, l, c, v: Math.random() * 1000 });
      p = c;
    }
    state.candles = out;
    state.livePrice = state.livePrice || p;
    txt('dsCandles', String(out.length));
  }

  function getState(){ return state; }

  return { changeAsset, changeTimeframe, changeBroker, connectSocket, closeSocket, seedCandles, getState, isCryptoSymbol, startSyntheticFeed };
})();

/* ---------- CHART ENGINE (canvas candle renderer) ---------- */
const ntChart = (() => {
  function dpr(){ return window.devicePixelRatio || 1; }

  function resize(){
    const c = $('mainChart'); if (!c) return;
    const w = c.parentElement.clientWidth - 28; // padding
    const h = 380;
    c.style.width = w + 'px';
    c.style.height = h + 'px';
    c.width = Math.round(w * dpr());
    c.height = Math.round(h * dpr());
  }

  function render(){
    const c = $('mainChart'); if (!c) return;
    const ctx = c.getContext('2d');
    const cs = ntMarket.getState().candles;
    if (!cs.length) return;
    const W = c.width, H = c.height;
    ctx.clearRect(0,0,W,H);

    // Background grid
    ctx.fillStyle = 'rgba(56,189,248,0.02)';
    ctx.fillRect(0,0,W,H);
    ctx.strokeStyle = 'rgba(56,189,248,0.08)';
    ctx.lineWidth = 1 * dpr();
    const rows = 6;
    for (let i=0;i<=rows;i++){
      const y = (H/rows)*i;
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(W,y); ctx.stroke();
    }

    // Price range
    let mn = Infinity, mx = -Infinity;
    cs.forEach(k => { if (k.l < mn) mn = k.l; if (k.h > mx) mx = k.h; });
    const pad = (mx - mn) * 0.08;
    mn -= pad; mx += pad;
    const yOf = p => H - ((p - mn) / (mx - mn)) * (H - 30*dpr()) - 15*dpr();

    // Candle width
    const wPad = 18 * dpr();
    const cw = Math.max(2*dpr(), Math.floor((W - 2*wPad) / cs.length) - 2*dpr());
    const step = (W - 2*wPad) / cs.length;

    // Draw candles
    cs.forEach((k, i) => {
      const x = wPad + i * step + step/2;
      const up = k.c >= k.o;
      ctx.strokeStyle = up ? '#22c55e' : '#ef4444';
      ctx.fillStyle = up ? 'rgba(34,197,94,0.85)' : 'rgba(239,68,68,0.85)';
      ctx.lineWidth = 1 * dpr();
      // Wick
      ctx.beginPath();
      ctx.moveTo(x, yOf(k.h));
      ctx.lineTo(x, yOf(k.l));
      ctx.stroke();
      // Body
      const yo = yOf(k.o), yc = yOf(k.c);
      const top = Math.min(yo, yc), bh = Math.max(1.5*dpr(), Math.abs(yc - yo));
      ctx.fillRect(x - cw/2, top, cw, bh);
    });

    // MA20
    const ma = [];
    for (let i=0;i<cs.length;i++){
      if (i < 19){ ma.push(null); continue; }
      let s=0; for (let j=i-19;j<=i;j++) s += cs[j].c;
      ma.push(s/20);
    }
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 1.6 * dpr();
    ctx.beginPath();
    let started = false;
    ma.forEach((m,i) => {
      if (m == null) return;
      const x = wPad + i * step + step/2;
      const y = yOf(m);
      if (!started){ ctx.moveTo(x,y); started = true; } else ctx.lineTo(x,y);
    });
    ctx.stroke();

    // Last price line
    const lastC = cs[cs.length-1].c;
    ctx.strokeStyle = 'rgba(56,189,248,0.5)';
    ctx.setLineDash([4*dpr(), 4*dpr()]);
    ctx.beginPath();
    ctx.moveTo(0, yOf(lastC));
    ctx.lineTo(W, yOf(lastC));
    ctx.stroke();
    ctx.setLineDash([]);

    // Price label on right
    ctx.fillStyle = 'rgba(56,189,248,0.95)';
    ctx.font = `${11*dpr()}px Inter, sans-serif`;
    const lbl = fmtPrice(lastC, ntMarket.getState().symbol);
    const w = ctx.measureText(lbl).width + 12*dpr();
    ctx.fillRect(W - w - 4*dpr(), yOf(lastC) - 8*dpr(), w, 16*dpr());
    ctx.fillStyle = '#03192b';
    ctx.fillText(lbl, W - w + 2*dpr(), yOf(lastC) + 4*dpr());

    // Broker overlay label (top-left, subtle)
    ctx.fillStyle = 'rgba(245,158,11,0.7)';
    ctx.font = `${10*dpr()}px Inter, sans-serif`;
    ctx.fillText(ntMarket.getState().broker.toUpperCase() + ' OVERLAY', 12*dpr(), 18*dpr());
  }

  function init(){
    resize();
    window.addEventListener('resize', () => { resize(); render(); });
    render();
  }

  return { init, render, resize };
})();

/* ---------- SIGNAL ENGINE ---------- */
const ntSignals = (() => {

  function quotaKey(){
    const d = new Date().toISOString().slice(0,10);
    return `ntp_v14_quota_${(ntAuth.session().email || 'guest')}_${d}`;
  }
  function quotaUsed(){ return Number(localStorage.getItem(quotaKey()) || 0); }
  function setQuota(n){ localStorage.setItem(quotaKey(), String(n)); }

  function daysLeft(){
    const s = ntAuth.session();
    if (!s.trialEnd) return NT_CONFIG.TRIAL_DAYS;
    return Math.max(0, Math.ceil((s.trialEnd - Date.now()) / 86400000));
  }
  function canGenerate(){
    if (ntAuth.isPaid()) return true;
    return daysLeft() > 0 && quotaUsed() < NT_CONFIG.DAILY_SIGNAL_LIMIT;
  }

  function refreshQuota(){
    const used = quotaUsed();
    const left = Math.max(0, NT_CONFIG.DAILY_SIGNAL_LIMIT - used);
    const q = $('quotaLine');
    if (!q) return;
    if (ntAuth.isPaid()){
      q.textContent = 'Paid subscription active — unlimited Signal Switch.';
      q.classList.add('paid');
    } else {
      q.classList.remove('paid');
      q.textContent = `Free trial: ${left} of ${NT_CONFIG.DAILY_SIGNAL_LIMIT} signal switches left today · ${daysLeft()} days remaining`;
    }
    const btn = $('signalSwitchBtn');
    if (btn){
      const lock = !canGenerate();
      btn.disabled = lock;
      btn.querySelector('span:last-child').textContent =
        lock ? (daysLeft() > 0 ? 'DAILY LIMIT — SUBSCRIBE' : 'TRIAL EXPIRED — SUBSCRIBE') : 'SIGNAL SWITCH';
    }
    txt('portalSignalsUsed', `${used} / ${NT_CONFIG.DAILY_SIGNAL_LIMIT}`);
  }

  function decideSide(){
    const cs = ntMarket.getState().candles;
    if (cs.length < 25) return Math.random() > 0.5 ? 'BUY' : 'SELL';
    const last = cs[cs.length-1].c;
    let ma=0; for (let i=cs.length-20;i<cs.length;i++) ma += cs[i].c;
    ma /= 20;
    // Lean against MA, plus small RNG seasoning
    const lean = last > ma ? 'BUY' : 'SELL';
    return Math.random() < 0.75 ? lean : (lean === 'BUY' ? 'SELL' : 'BUY');
  }

  function calcSignal(variant){
    const st = ntMarket.getState();
    const sym = st.symbol;
    const symLabel = $('assetSelect').options[$('assetSelect').selectedIndex].text;
    const broker = st.broker;
    const provider = NT_CONFIG.BROKER_PROVIDER_MAP[broker] || broker;
    const side = decideSide();
    const p = st.livePrice || NT_CONFIG.STATIC_BASE[sym] || 100;
    const mult =
      /BTC|ETH|BNB|SOL/.test(sym) ? 0.006 :
      /V75|V100|BOOM|CRASH/.test(sym) ? 0.0035 :
      /XAU/.test(sym) ? 0.0022 :
      /JPY/.test(sym) ? 0.0014 : 0.0012;
    const risk = p * mult * (variant === 'B' ? 1.25 : 1);
    const entry = variant === 'B' ? p + (side === 'BUY' ? risk*0.18 : -risk*0.18) : p;
    const sl = side === 'BUY' ? entry - risk : entry + risk;
    const tp = side === 'BUY' ? entry + risk * 1.8 : entry - risk * 1.8;
    const baseConf = 62 + Math.round(Math.random() * 26);
    const conf = variant === 'A' ? baseConf : Math.max(54, baseConf - 4 - Math.round(Math.random()*5));
    const quality = Math.max(55, Math.min(96, conf + Math.round((Math.random()-0.5) * 8)));
    return { variant, sym, symLabel, broker, provider, side, entry, sl, tp, conf, quality, rr:'1:1.8', t: Date.now() };
  }

  function profitExamples(sig){
    const move = Math.abs(sig.tp - sig.entry);
    const factor =
      /BTC|ETH|BNB|SOL/.test(sig.sym) ? 0.04 :
      /V75|V100|BOOM|CRASH/.test(sig.sym) ? 0.018 :
      /XAU/.test(sig.sym) ? 1.0 :
      /JPY/.test(sig.sym) ? 0.65 : 10;
    return [0.01, 0.05, 0.10]
      .map(l => `Lot ${l.toFixed(2)} ≈ $${Math.max(0.5, move * factor * l * 10).toFixed(2)}`)
      .join(' · ');
  }

  function renderCard(sig){
    const c = `signal-card ${sig.side === 'BUY' ? 'buy' : 'sell'}`;
    return `<div class="${c}" data-variant="${sig.variant}">
      <div class="head">
        <h4>SIGNAL ${sig.variant}</h4>
        <span class="provider">${sig.provider}</span>
      </div>
      <div class="side ${sig.side}">${sig.side}</div>
      <div class="signal-row"><span>Market</span><b>${sig.symLabel}</b></div>
      <div class="signal-row"><span>Entry</span><b>${fmtPrice(sig.entry, sig.sym)}</b></div>
      <div class="signal-row"><span>Stop Loss</span><b style="color:var(--sell)">${fmtPrice(sig.sl, sig.sym)}</b></div>
      <div class="signal-row"><span>Take Profit</span><b style="color:var(--buy)">${fmtPrice(sig.tp, sig.sym)}</b></div>
      <div class="signal-row"><span>Confidence</span><b style="color:var(--primary)">${sig.conf}%</b></div>
      <div class="signal-row"><span>Quality</span><b>${sig.quality}/100</b></div>
      <div class="signal-row"><span>Risk : Reward</span><b>${sig.rr}</b></div>
      <div class="signal-profits"><b>Profit example:</b> ${profitExamples(sig)}</div>
    </div>`;
  }

  function generate(){
    if (!canGenerate()){
      notify(daysLeft() > 0 ? 'Daily free limit reached. Subscribe to continue.' : 'Trial expired. Subscribe to continue.', 'warn');
      refreshQuota();
      return;
    }
    const a = calcSignal('A');
    const b = calcSignal('B');
    const out = $('signalOutput');
    if (out) out.innerHTML = renderCard(a) + renderCard(b);
    if (!ntAuth.isPaid()) setQuota(quotaUsed() + 1);
    pushHistory(a); pushHistory(b);
    refreshSummary(a);
    refreshQuota();
    notify(`Two signals generated · A=${a.side} · B=${b.side}`, 'success');
  }

  function relabelProvider(){
    // Update the provider chip on existing rendered signal cards when broker changes
    const out = $('signalOutput'); if (!out) return;
    const provider = NT_CONFIG.BROKER_PROVIDER_MAP[ntMarket.getState().broker] || ntMarket.getState().broker;
    out.querySelectorAll('.signal-card .provider').forEach(el => {
      el.textContent = provider;
    });
  }

  function refreshSummary(sig){
    // Build a quick summary even without an explicit signal
    const cs = ntMarket.getState().candles;
    if (!cs.length) return;
    const last = cs[cs.length-1].c;
    let ma=0; for (let i=cs.length-20;i<cs.length;i++) ma += cs[i].c;
    ma /= 20;
    const bias = last > ma ? 'BULLISH' : 'BEARISH';
    const conf = sig ? sig.conf : 55 + Math.round(Math.random()*25);
    const quality = sig ? sig.quality : Math.round(conf + (Math.random()-0.5)*6);
    const side = sig ? sig.side : (bias === 'BULLISH' ? 'BUY' : 'SELL');
    const grade = conf > 80 ? 'A+' : conf > 70 ? 'A' : conf > 60 ? 'B' : 'C';
    $('signalGrade').textContent = grade;
    $('signalGrade').className = `grade-badge ${side}`;
    $('signalText').textContent = side;
    $('signalText').className = `big-signal ${side}`;
    txt('confValue', conf + '%');
    $('confBar').style.width = conf + '%';
    txt('marketBias', bias);
    txt('summaryQuality', quality + '/100');
    txt('trendState', last > ma ? 'Uptrend' : 'Downtrend');
    txt('volumeState', Math.random() > 0.5 ? 'Above avg' : 'Normal');
  }

  /* ---- HISTORY ---- */
  function historyKey(){ return `ntp_v14_history_${ntAuth.session().email || 'guest'}`; }
  function pushHistory(sig){
    const arr = JSON.parse(localStorage.getItem(historyKey()) || '[]');
    arr.unshift(sig);
    if (arr.length > 200) arr.length = 200;
    localStorage.setItem(historyKey(), JSON.stringify(arr));
    txt('portalSignalsTotal', String(arr.length));
    renderHistory();
  }
  function renderHistory(){
    const arr = JSON.parse(localStorage.getItem(historyKey()) || '[]').slice(0, 12);
    const el = $('historyList'); if (!el) return;
    if (!arr.length){ el.innerHTML = '<div class="history-empty">No history yet.</div>'; return; }
    el.innerHTML = arr.map(s => `
      <div class="history-item">
        <span class="side-tag ${s.side}">${s.side}</span>
        <div class="meta">
          <b>${s.symLabel || s.sym}</b> · ${s.provider}
          <small>${fmtTime(s.t)} · Entry ${fmtPrice(s.entry, s.sym)}</small>
        </div>
        <span class="conf">${s.conf}%</span>
      </div>
    `).join('');
  }

  function init(){
    refreshQuota();
    refreshSummary();
    renderHistory();
  }

  return { init, generate, refreshQuota, refreshSummary, relabelProvider, renderHistory };
})();

/* ---------- BILLING (subscription unlock) ---------- */
const ntBilling = (() => {
  function subscribe(plan){
    const s = ntAuth.session();
    if (!s.email){ notify('Sign in first', 'warn'); return; }
    // In production: redirect to PayFast / Ozow / Peach. For now: mock unlock for 30 days.
    s.plan = plan;
    s.paidUntil = Date.now() + 30 * 86400000;
    localStorage.setItem('ntp_v14_session', JSON.stringify(s));
    ntAuth.session(); // refresh
    document.location.reload();
  }
  return { subscribe };
})();

/* ---------- APP ROUTER ---------- */
const ntApp = (() => {
  function showPage(name){
    ['trading','user','plans','owner'].forEach(p => {
      const el = $('page' + p[0].toUpperCase() + p.slice(1));
      if (el) el.classList.toggle('active', p === name);
      const btn = $('nav' + p[0].toUpperCase() + p.slice(1));
      if (btn) btn.classList.toggle('active', p === name);
    });
    if (name === 'owner' && !ntAuth.isOwner()){
      notify('Owner portal restricted', 'error');
      showPage('trading');
    }
  }

  function showLegal(which){
    const msgs = {
      risk: 'RISK DISCLOSURE: Trading carries significant risk. Signals are estimates, never guarantees. You are responsible for your own trades.',
      terms: 'TERMS: NetTrack is a signal platform only. Subscriptions unlock signal features; NetTrack never holds, deposits or trades client funds.',
      privacy: 'PRIVACY: NetTrack stores login/session/signal limits locally and in Supabase (if connected). No selling of user data.'
    };
    alert(msgs[which] || 'Legal');
  }

  function acceptCookies(){
    localStorage.setItem('ntp_v14_cookie_ok', '1');
    $('cookieBanner').classList.add('hidden');
  }

  function maybeShowCookies(){
    if (!localStorage.getItem('ntp_v14_cookie_ok')){
      setTimeout(() => $('cookieBanner').classList.remove('hidden'), 1500);
    }
  }

  function hideSplash(){
    setTimeout(() => {
      $('splashScreen').classList.add('fade');
      setTimeout(() => $('splashScreen').remove(), 700);
    }, 1400);
  }

  function init(){
    hideSplash();
    ntAuth.init();
    // Push initial TF + Broker into the data-strip / chips
    txt('dsTF', $('tfSelect').value);
    txt('chipTF', $('tfSelect').value);
    txt('dsBroker', $('brokerSelect').value);
    txt('chipBroker', $('brokerSelect').value + ' Overlay');
    ntMarket.changeAsset(); // seeds + connects socket
    ntChart.init();
    ntSignals.init();
    maybeShowCookies();
    // Light refresh loop for summary (every 6s)
    setInterval(() => { ntSignals.refreshSummary(); }, 6000);
  }

  return { init, showPage, showLegal, acceptCookies };
})();

/* ---------- BOOT ---------- */
document.addEventListener('DOMContentLoaded', ntApp.init);
