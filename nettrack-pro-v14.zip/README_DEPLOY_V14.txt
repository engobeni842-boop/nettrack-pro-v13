================================================================
NETTRACK PRO V14 — PREMIUM SIGNAL PLATFORM
ARMOROO E n T Software and Apps
Created by Emmanuel Musiyiwa Ngobeni & Thando Mbatha
================================================================

WHAT'S NEW IN V14 (vs V13.4):
-----------------------------
FIXES
 [x] WebSocket reconnect bug fixed
     - Clean lifecycle: connect → onopen → onclose → exponential backoff
     - No more stuck "DISCONNECTED" socket label
     - Socket dot turns GREEN when live, RED when reconnecting
 [x] Broker switch no longer breaks the USD price feed
     - Broker selector is now a VISUAL OVERLAY ONLY
     - Live price stream (Binance WebSocket) is decoupled from broker label
 [x] Removed legacy patch-stacking (V10.7 → V13.4 chained patches)
     - V14 is a single coherent file with one state machine
     - No mutation-loop setInterval(boot, 1500) — single ntApp.init() boot

NEW FEATURE — ⚡ SIGNAL SWITCH BUTTON
 [x] Prominent green button sitting INSIDE the chart toolbar
 [x] Perfectly aligned with the chart card (sticky to top-right of chart)
 [x] Click → generates Signal A + Signal B beneath the chart (2-up grid,
     chart-aligned width)
 [x] BROKER TRANSITION TOAST (overlaid inside chart card):
     "Exness → IQ Option · signals replaced"
     Plays automatically when user switches broker dropdown.
     Notification toast also fires: "Switched from Exness to IQ Option —
     Exness signals replaced with IQ Option signals"
 [x] Existing Signal A/B cards live-relabel their provider tag when the
     broker changes (so an open IQ signal becomes labeled "IQ Option"
     instead of "Exness" instantly)

SUBSCRIPTION RESTRICTIONS APPLIED
 [x] Free trial:    2 signal switches/day, 30 days
 [x] Locked cards (visible but blurred with 🔒 overlay):
       - Signal History (90-day export)        → Pro
       - Strongest Pair Scanner (30+ markets)  → Premium
       - Historical Backtest engine            → Pro
 [x] Owner portal hidden from non-owner accounts
 [x] All 3 plans live on a dedicated PLANS page:
       Basic   R 149/mo
       Pro     R 349/mo  (featured)
       Premium R 799/mo

REMOVED CLUTTER
 [x] NetTrack Bot (auto-trading) — REMOVED
 [x] Mark Win / Mark Loss journal — REMOVED
 [x] Face verification / Selfie KYC — REMOVED
 [x] Deposit / Withdraw / Bank account fields — REMOVED
 [x] Old V10.7 → V13.4 patch comments — REMOVED

FILE STRUCTURE
--------------
nettrack-pro-v14/
  index.html                            ← root, opens directly
  app.js                                ← all app logic (auth, chart, signals, billing, router)
  sw.js                                 ← Service Worker (network-first for HTML/JS)
  manifest.webmanifest                  ← PWA manifest
  icon-192.png                          ← PWA icon (192x192)
  icon-512.png                          ← PWA icon (512x512)
  nettrack_signal_platform_schema.sql   ← Supabase schema (unchanged from V13)
  README_DEPLOY_V14.txt                 ← this file


HOW TO DEPLOY (GitHub Pages)
----------------------------
1. EXTRACT this ZIP locally.
2. Go to:   https://github.com/engobeni842-boop/nettrack-pro-v13/upload/main
   (or your new V14 repo)
3. Upload ALL extracted files (NOT the ZIP itself).
4. Commit changes.
5. Wait 30-60 seconds for GitHub Pages to rebuild.
6. Test the live URL.

HOW TO DEPLOY (Netlify)
-----------------------
1. Drag the extracted folder into Netlify Drop.
2. Done. Your URL is live in seconds.


HOW TO CONNECT SUPABASE (optional, for cloud accounts + signal history)
-----------------------------------------------------------------------
1. Create a Supabase project at https://supabase.com
2. Open SQL Editor → paste the contents of
   nettrack_signal_platform_schema.sql → Run.
3. Get your project URL + anon public key from Settings → API.
4. In index.html, add this BEFORE <script src="app.js">:

     <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
     <script>
       window.supabaseClient = supabase.createClient(
         'YOUR_PROJECT_URL',
         'YOUR_ANON_KEY'
       );
     </script>

5. The signal engine will auto-write to public.signal_history when
   window.supabaseClient is present. The Owner Portal cards
   (subscriptions, MRR, signal counts) can be wired to your service-role
   edge function later.


HOW TO CONNECT PAYMENT (PayFast / Ozow / Peach)
-----------------------------------------------
The "Subscribe" buttons currently mock a 30-day unlock locally
(for testing). To go live:

1. Get a merchant account with PayFast / Ozow / Peach.
2. Build a tiny serverless endpoint (Supabase Edge Function or
   Cloudflare Worker) that:
     a. Creates a payment session for the chosen plan amount (R149/349/799)
     b. Receives the webhook callback (status=paid) and writes the row
        to public.subscriptions with paid_until = now() + 30 days.
3. Replace ntBilling.subscribe() inside app.js with a redirect to
   the payment URL returned by your endpoint.


SAFETY / COMPLIANCE NOTES
-------------------------
- NetTrack is a SIGNAL PLATFORM ONLY.
- NetTrack does NOT hold client funds.
- NetTrack does NOT execute trades.
- NetTrack does NOT have access to user broker accounts.
- All signal outputs are estimates; profit examples are illustrative.
- Users trade manually on their own broker accounts at their own risk.

The Risk Disclosure / Terms / Privacy mini-links are visible on every
page (bottom-left corner of the screen).


CREDITS
-------
Owner:      Emmanuel Musiyiwa Ngobeni
Co-owner:   Thando Mbatha
Brand:      ARMOROO E n T Software and Apps
Build:      V14.0.0 — Premium Signal Platform
================================================================
